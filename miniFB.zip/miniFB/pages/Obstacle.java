package obstacle;
public class Obstacle{
	public int x;
	public int y;
	public int dx;
	public int dy;
}