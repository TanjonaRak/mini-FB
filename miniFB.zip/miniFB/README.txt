==>copier tous les scriptes dans le BdD dans votre MYSQL
==>et copier le projet dans votre WEB server
==>Et apres lancez le projet